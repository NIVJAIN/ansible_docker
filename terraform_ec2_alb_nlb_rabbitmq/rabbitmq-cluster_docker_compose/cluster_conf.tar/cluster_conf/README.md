Two RabbitMQ nodes in cluster using [Docker compose](https://docs.docker.com/compose/)

```
git clone https://github.com/Gsantomaggio/rabbitmqexample.git .
cd cluster_docker_compose/cluster_conf/
docker-compose up
```

You can customize the `rabbitmq.config` inside `conf/rabbitmq.config`




